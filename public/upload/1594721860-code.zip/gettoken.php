<!DOCTYPE html>
<html lang="en">
<head>
  <title>Lấy Mã Token Facebook</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <br>
  <h2>Lấy mã Token & Cookie Facebook</h2>
    <p>
      Để lấy thông tin từ tài khoản Facebook đặc biệt là lấy token và cookie thì rất khó khăn cho bạn bởi Facebook dễ gây ra tình trạng checkpoint (xác minh danh tính). Giờ dây khi sử dụng Panda Token & Cookie addon thì bạn không còn lo lắng. Chỉ vài thao tác bạn có thể lấy token và cookies dễ dàng. Bạn có thể mang cookies để cấu hình tài khoản trong trang chủ.<br>
    <b>
    HƯỚNG DẪN CÀI ĐẶT PANDA TOKEN & COOKIE <br></b><br>
    <b style="color: red;">
Bước 1 :</b> Bạn tải link addon cho google chrome hoặc cốc cốc<br><br>
<a type="button" class="btn btn-danger" style="color: white;">Tải về</a><br> <br>
    <b style="color: red;">
Bước 2 :</b> Sau khi tải xong bạn mở Chrome hoặc Cốc Cốc chọn Công cụ khác -> Tiện ích mở rộng (Xem hình bên dưới)<br><br>
<img src="buoc2.png"><br><br>
<b style="color: red;">
Bước 3 :</b> Bật chế độ cài đặt addon ở nhà phát triển -> Tải tiện ích đã giải nén (Xem hình bên dưới)<br><br>
<img src="buoc3.png" width="1000px">
<b style="color: red;">
Bước 4 :</b> Chọn đến foler giải nén của addon Panda Token & Cookie (Xem hình bên dưới)<br><br>
<img src="buoc4.png" width="1000px">
</div>

</body>
</html>
